<?php

namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\ProductDetails;
use Illuminate\Http\Request;
use Validator;
class ProductDetailsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $rules =[
            'product_id' =>'required|numeric',
        ];
        $validator = Validator::make(request()->all() , $rules);
        if($validator->fails()){
            falseResult(401,'Validation Error please check your input');
        }
        else{
            $product_details =  ProductDetails::where('product_id',$request->product_id)->first();
            if($product_details){
                $product_details->image = 'http://www.vretech.com/images/products/'.$product_details->category_image;
                trueresult(200,'Success request',$product_details);
            }
            else{
                falseResult(401,'No Data hes been found');
            }
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ProductDetails  $productDetails
     * @return \Illuminate\Http\Response
     */
    public function show(ProductDetails $productDetails)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ProductDetails  $productDetails
     * @return \Illuminate\Http\Response
     */
    public function edit(ProductDetails $productDetails)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProductDetails  $productDetails
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProductDetails $productDetails)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ProductDetails  $productDetails
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProductDetails $productDetails)
    {
        //
    }
}
